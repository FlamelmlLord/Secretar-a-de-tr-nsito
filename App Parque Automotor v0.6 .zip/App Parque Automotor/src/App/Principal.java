
package App;
import Controlador.Controlador_L;
import Controlador.Controlador_P;

import Vista.LOGIN;

public class Principal {

    public static void main(String[] args) {
        
        Controlador_L ControlLogin = new Controlador_L();
        Controlador_P control_p = new Controlador_P();

    }
}
